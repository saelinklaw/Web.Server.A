### Fix

* Reduce binary file size.
